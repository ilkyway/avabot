from telethon.sync import TelegramClient
from telethon.tl.functions.photos import UploadProfilePhotoRequest, DeletePhotosRequest
import random
import os
import time
api_id = 28380826
api_hash = 'f82ed2a6755fa7e49714da59a9355cff'
name = "zixman"
client = TelegramClient(name, api_id, api_hash)
with TelegramClient(name, api_id, api_hash) as client:
	pass
	def DeleteAvatar():
		client(DeletePhotosRequest(client.get_profile_photos('me')))
	def ChangeAvatar(avatar):
		filea= client.upload_file(f'avatars/{avatar}')
		proc = UploadProfilePhotoRequest(filea)
		client(proc)
	def RandomAvatar():
	   print("[+]Choice avatar...")
	   file = random.choice(os.listdir('avatars/'))
	   print("[+]Delete old avatar...")
	   DeleteAvatar()
	   print("[+]Uplod new avatar...")
	   ChangeAvatar(file)
	   print("[+]Changed!")
	   print("[+]Sending Info message...")
	   client.send_message(entity=client.get_entity('https://t.me/avatarszixman'),message=f"[INFO]Avatar Change to {file}")
	   print("[+]Successfully!")
	   print("-----------------------------")
	def Connect():
		client.connect()

Connect()
while True:
	RandomAvatar()
	time.sleep(60)

client.start()
client.run_until_disconnected()